import Email from "../assets/message.svg"
import Contact from "../assets/contact.svg"
import Timer from "../assets/timer.svg"
import Moneybag from "../assets/moneybag.svg"

export const infoCardsArray = [
    {
      value: "50%",
      desc: "email open rate",
      icon: Email,
    },
    {
      value: "100%",
      desc: "content click rate",
      icon: Contact,
    },
    {
      value: "22:53",
      desc: "total time spent",
      icon: Timer,
    },
    {
      value: "$ 367",
      desc: "deal value",
      icon: Moneybag,
    },
  ];