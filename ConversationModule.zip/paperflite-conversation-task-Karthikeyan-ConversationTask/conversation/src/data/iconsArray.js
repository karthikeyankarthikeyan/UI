import Seek from '../assets/seek.svg'; 
import Hub from '../assets/hub.svg';
import Collection from '../assets/collection.svg';
import Engage from '../assets/engage.svg';
import Report from '../assets/report.svg';
import Compose from '../assets/compose.svg';

export const iconsArray = [
    {
      name: "search",
      url: Seek,
    },
    {
      name: "Content Hub",
      url: Hub,
    },
    {
      name: "Collection",
      url: Collection,
    },
    {
      name: "Engage",
      url: Engage,
    },
    {
      name: "Report",
      url: Report,
    },
    {
      name: " Quicksend",
      url: Compose,
    },
  ];