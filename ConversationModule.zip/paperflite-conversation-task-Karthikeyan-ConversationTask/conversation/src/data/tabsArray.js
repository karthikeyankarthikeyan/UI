export const tabsArray = [
    {
      tabTitle: "Recipients",
      count: "08",
      isActive: true,
    },
    {
      tabTitle: "Sections",
      count: "05",
      isActive: false,
    },
  ];