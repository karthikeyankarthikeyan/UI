import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import "./App.css";
import NavbarMobile from "./components/sidebar/navbarMobile";
import NavbarDesktop from "./components/sidebar/navbarDesktop";
import Conversation from "./components/conversation/conversationtab";

const App = () => {
  const [displayWidth, setDisplayWidth] = useState(window.innerWidth);
  
  useEffect(() => {
    const handleResize = () => {
      setDisplayWidth(window.innerWidth);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <Router>
      <div className="main">
        <div className="body">
          <Routes>
            <Route path="/conversations" element={<Conversation displayWidth={displayWidth} />} />
            <Route path="*" element={<Navigate to="/conversations" />} />
          </Routes>
        </div>
        <div className="nav">
          {displayWidth >= 768 ? <NavbarDesktop /> : <NavbarMobile />}
        </div>
      </div>
    </Router>
  );
};

export default App;
