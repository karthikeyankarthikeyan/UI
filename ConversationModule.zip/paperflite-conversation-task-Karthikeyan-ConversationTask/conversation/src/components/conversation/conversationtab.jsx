import React from "react";
import conversationsData from '../../data/conversations.json';
import Filter from  '../../assets/filter.svg'
import Collection from "./collectionseektab";

const Conversation = ({ displayWidth }) => {

  return (
    <div className="conversationContainer">
      {displayWidth >= 768 ? (
        <div className="conversationContainer2">
          <div className="conversationList">
            <div className="conversationListTitle">
              <h1 className="conversationListTitle-h1">
                conversations
              </h1>
              <div className="option cursorPointer">
                <span className="filterIcon">
                  <img
                    src={Filter}
                    alt=""
                  />
                </span>
              </div>
            </div>
            <p className="conversationListTitle-p">track user engagement</p>
          </div>
          <div className="conversationList-input">
            <div className="searchBox">
              <input
                type="text"
                placeholder="search by conversations and contacts"
              />
            </div>
            <div className="filter">
              <p>Sort by :</p>
              <p className="pred cursorPointer">Created Date</p>
              <p className="cursorPointer">Last Activity</p>
              <p className="cursorPointer">Time Spent</p>
            </div>
          </div>
          <div className="conversationList-content">
            {conversationsData.map(convo => (
              <div className="conversationItem cursorPointer" key={convo.id}>
                <img height={95} width={85} src={convo.image} alt={convo.title} />
                <div className="conversationItem-content">
                  <div className="content-1">
                    <p className={`content-1-title ${convo.active ? 'active' : ''}`}>{convo.title}</p>
                    <p className="content-1-lastShared">{convo.lastShared}</p>
                  </div>
                  <div className="content-2">
                    <p>{convo.usedBy}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}
      <Collection displayWidth={displayWidth} />
    </div>
  );
};

export default Conversation;
