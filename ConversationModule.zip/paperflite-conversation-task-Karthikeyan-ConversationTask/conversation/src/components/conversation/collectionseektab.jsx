import React from "react";
import styles from "../conversation/styles.css";
import conversationDetails from '../../data/conversationDetails.json';
import {infoCardsArray} from '../../data/infoCardsArray';
import {tabsArray} from '../../data/tabsArray';
import View from '../../assets/view.svg';
import Refresh from '../../assets/refresh.svg';
import Delete from '../../assets/delete.svg';
import Email from "../../assets/message.svg"
import Contact from "../../assets/contact.svg"
import Share from "../../assets/share.svg"
import Location from "../../assets/location.svg"
import Message from "../../assets/email.svg"


const Collection = ({ displayWidth }) => {

  return (
    <div className="collectionContainer">
      <div className={ displayWidth > 768 ? "collectionContainerSection1" : "mobilecollectionContainerSection1"} />
      <div className="collectionContainerSection2">
        <div className="collectionContainerSection2Main">
          <div className="titleCard">
            <h1 className="title">
              Collection “seeeek”
            </h1>
            {displayWidth >= 768 && (
              <div className="options">
                <div className="option cursorPointer">
                  <span className="iconSpan">
                    <img src={View}alt="" />
                  </span>
                </div>
                <div className="option cursorPointer">
                  <span className="iconSpan">
                    <img src={Refresh} alt="" />
                  </span>
                </div>
                <div className="option cursorPointer">
                  <span className="iconSpan">
                    <img src={Delete}  alt="" />
                  </span>
                </div>
              </div>
            )}
          </div>
          <div className="DescCard">
            <p className="paragraph">You shared 2 assets with 4 recipients</p>
            <p className="paragraph2">1 month ago via QuickSend</p>
          </div>
          <div className="InfoCards">
            {infoCardsArray.map((info) => (
              <div className="InfoCard" key={info.desc}>
                <div className="topLevelInfo">
                  <p className="topLevelInfoDesc">{info.value}</p>
                  <span>
                    <img src={info.icon} alt="" />
                  </span>
                </div>
                <p className="bottomLevelInfoDesc">{info.desc}</p>
              </div>
            ))}
          </div>
          <div className="sectionTabs">
            { tabsArray.map((tab) => (
              <div className="tabMain cursorPointer" key={tab.tabTitle}>
                <div className={`tabTitle ${tab.isActive ? "active" : "notActive"}`}>
                  <span>{tab.tabTitle}</span> - 
                  <span className={`tabNumber ${tab.isActive ? "active" : "notActive"}`}>
                    {tab.count}
                  </span>
                </div>
                {tab.isActive && <hr className="separator" />} 
              </div>
            ))}
          </div>
        </div>
        <div className="tabSectionContent">
          <div className="tabContent">
            {conversationDetails.map((content) => (
              <div className="tabContentItems" key={content.id}>
                <div className="tabContentSection1">
                  <img className="tabContentSection1Img cursorPointer" height={40} width={40} alt='' src={content.profile} />
                  <p className="tabContentSection1Name cursorPointer">{content.name}</p>
                  {displayWidth >= 768 && <div className="divider"></div>}
                  {displayWidth >= 768 && <p className="tabContentSection1LastSeen">{content.lastView}</p>}
                </div>
                <div className="tabContentSection2">
                  <p className="tabContentSection1LastSeen">{content.time}</p>
                  <span className="cursorPointer">
                    <img src={Message} alt="message" />
                  </span>
                  <span className="cursorPointer">
                    <img src={Contact} alt="contact" />
                  </span>
                  <span className="cursorPointer">
                    <img src={Share} alt="share" />
                  </span>
                  {displayWidth >= 768 && <div className="divider"></div>}
                  {displayWidth >= 768 && (
                    <div className="option cursorPointer">
                      <span className="iconSpan">
                        <img src={Location} alt="location" />
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Collection;

