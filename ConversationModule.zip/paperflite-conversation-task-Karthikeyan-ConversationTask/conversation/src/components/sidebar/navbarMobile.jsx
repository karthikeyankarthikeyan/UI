import React from "react";
import Hub from "../../assets/hub.svg";
import Collections from "../../assets/collection.svg";
import Engage from "../../assets/engageactive.svg";
import styles from "./navbar.module.css";

const NavbarMobile = () => {

    
  return (
    <div className={styles.navbarMobileContainer}>
     
        <span>
          <img src={Hub} alt="Hub" />
        </span>
     
        <span>
          <img src={Collections} alt="Collection" />
        </span>
      
        <span>
          <img src={Engage} alt="Engage" />
        </span>
     
    </div>
  );
};

export default NavbarMobile;