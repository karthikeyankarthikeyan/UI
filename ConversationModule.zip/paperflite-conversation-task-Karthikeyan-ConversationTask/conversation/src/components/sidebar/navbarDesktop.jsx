import React from "react";
import { iconsArray } from "../../data/iconsArray";
import Setting from '../../assets/setting.svg';
import Account from '../../assets/account.png';
import styles from "./navbar.module.css";

const NavbarDesktop = () => {
  return (
    <div className={styles.navbarDesktopContainer}>
      <div className={styles.desktopIcons}>
        {iconsArray.map((icon) => (
          <span key={icon.name} className={styles.cursorPointer}>
            <img src={icon.url} alt={icon.name}/>
          </span>
        ))}
      </div>
      <div className={styles.settingsIcon}>
        <img className={styles.cursorPointer} src={Setting} alt="Setting" />
        <img className={`${styles.profilePicture} ${styles.cursorPointer}`} src={Account} alt="Profile" />
      </div>
    </div>
  );
};

export default NavbarDesktop;